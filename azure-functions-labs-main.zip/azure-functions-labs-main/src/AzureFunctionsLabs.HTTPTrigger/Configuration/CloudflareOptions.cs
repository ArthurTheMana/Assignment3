﻿namespace AzureFunctionsLabs.HTTPTrigger.Configuration
{
    public class CloudflareOptions
    {
        public string ZoneId { get; set; }
        public string Email { get; set; }
        public string AuthKey { get; set; }
    }
}
