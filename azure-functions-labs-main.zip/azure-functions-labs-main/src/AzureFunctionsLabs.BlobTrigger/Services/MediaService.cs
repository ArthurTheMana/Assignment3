﻿#region Imports
#endregion

namespace AzureFunctionsLabs.BlobTrigger.Services
{
    public class MediaService : IMediaService
    {
    }
}
