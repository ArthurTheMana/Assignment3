﻿#region Imports
#endregion

namespace AzureFunctionsLabs.BlobTrigger.Services
{
    public interface IMediaService
    {
    }
}
